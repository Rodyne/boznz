unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Label4: TLabel;
    Label5: TLabel;
    ArrayWidth: TEdit;
    SelSrc: TButton;
    SelDst: TButton;
    MaxSz: TEdit;
    Label3: TLabel;
    od: TOpenDialog;
    SrcFilename: TEdit;
    DstFilename: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure SelDstClick(Sender: TObject);
    procedure SelSrcClick(Sender: TObject);
    procedure SrcFilenameChange(Sender: TObject);
  private
    { private declarations }
  public
    { public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

const eol=#13+#10;

procedure TForm1.Button1Click(Sender: TObject);
var
  Fsrc:file of byte;
  Fdst:textfile;
  data:string;
  c:byte;
  ls,count,max:integer;
begin
  assignfile(Fsrc,SrcFilename.Text);
  assignfile(Fdst,DstFilename.text);
  try
    max:=strtoint(MaxSz.Text);
  except
    max:=10000000;
  end;
  reset(Fsrc);
  rewrite(Fdst);
  data:='{'+eol;
  ls:=0;
  count:=0;
  while (count<max) and not eof(Fsrc) do
  begin
    data:=data+'  ';
    for ls:=1 to ArrayWidth.tag do
    begin
      if (count<max) and not eof(Fsrc) then
      begin
        read(Fsrc,c);
        inc(count);
        data:=data+'0x'+IntTohex(c,2);
        if (count<max) and not eof(Fsrc) then data:=data+',';
        if (ls=ArrayWidth.tag) or (count>=max) or eof(Fsrc) then data:=data+eol;
      end;
    end;
  end;
  data:='// Created from '+SrcFilename.text+eol+
        'const unsigned char data['+inttostr(count)+']='+eol+
        data+
        '};';
  write(fdst,data);
  closefile(Fdst);
  closefile(Fsrc);
  messageDLG(inttostr(count)+' Bytes written to header file',mtinformation,[mbok],0);
end;

procedure TForm1.SelDstClick(Sender: TObject);
begin
  if od.Execute then dstFilename.text:=od.FileName;
end;

procedure TForm1.SelSrcClick(Sender: TObject);
begin
  if od.Execute then SrcFilename.text:=od.FileName;
end;

procedure TForm1.SrcFilenameChange(Sender: TObject);
begin
  Button1.Enabled:=true;
  try
    SrcFilename.Color:=clYellow;
    if SrcFilename.text='' then abort;
    SrcFilename.Color:=clDefault;
    DstFilename.Color:=clYellow;
    if dstfilename.text='' then abort;
    DstFilename.Color:=clDefault;
    ArrayWidth.color:=clyellow;
    ArrayWidth.tag:=Strtoint(ArrayWidth.text);
    ArrayWidth.color:=cldefault;
  except
    button1.enabled:=false;
  end;
end;


end.

