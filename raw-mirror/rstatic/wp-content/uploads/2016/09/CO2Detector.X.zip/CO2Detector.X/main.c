// 2016 Roving Dynamics Ltd (rodyne.com) Open Source CO2/Temperature and humidity Monitor

#include <xc.h>           // standard include for xc8 compiler supplied with mplabx
#include <pic18f24k22.h>  // standard include for xc8 compiler supplied with mplabx. Note Target MPU is PIC18F2xK22 @ 11.0952Mhz

#define uint8		unsigned char
#define uint16	unsigned short

// PIC8 Microcontroller Fuse settings

#pragma config FOSC = HSMP      // Ext XTAL Running at 11.0592Mhz (reason: lowest cost xtal and gives exact 9600 baud rate)
#pragma config PLLCFG = OFF     // No PLL
#pragma config CCP3MX = PORTB5	// check if req
#pragma config PBADEN = OFF			// ADC OFF (Port B is digital)
#pragma config WDTEN = ON			  // Watchdog timer on, will reset chip if I dont reset it within 65 seconds (must have for control systems)
#pragma config WDTPS = 16384  	// Watchdog timer prescaler is 65 seconds, this is how long I have to kick the mule before a reset happens
#pragma config STVREN = ON			// Stack overflow reset ON (Any stack probs then do a reset. Again Better safe than sorry!)
#pragma config BOREN = ON       // Turn on Brown-out reset so the device resets on any power problem (again max out the fail safe)

// *** Specific PIC18 Pin I/O's : changes here will also require change to TRIS in program main() startup!

#define LCD_EN(state)     LATAbits.LATA0 = state // Output for HD44780 LCD Enable Pin
#define LCD_RS(state)     LATAbits.LATA1 = state // Output for HD44780 RS Pin
#define ALM_LED(state)    LATAbits.LATA2 = state // Output for alarm led (incorporated in silence button)
#define LCD_D4(state)     LATBbits.LATB0 = state // Output for HD44780 D4 Pin
#define LCD_D5(state)     LATBbits.LATB1 = state // Output for HD44780 D5 Pin
#define LCD_D6(state)     LATBbits.LATB2 = state // Output for HD44780 D6 Pin
#define LCD_D7(state)     LATBbits.LATB3 = state // Output for HD44780 D7 Pin
#define SILENCE_BTN       !PORTBbits.RB4         // INPUT. Ground pin to silence alarm lo alarm if in lo alarm state, long hold to silence hi alarm, otherwise do nothing
#define DEBUG(state)      LATCbits.LATC0 = state // Output to alarm buzzer/speaker
#define BUZZER(state)     LATCbits.LATC1 = state // Output to alarm buzzer/speaker
#define HI_ALM(state)     LATCbits.LATC2 = state // Output to drive hi alarm relay
#define LO_ALM(state)     LATCbits.LATC3 = state // Output to drive lo alarm relay
#define CALIB(state)      LATCbits.LATC5 = state // Output to MH-Z19 set low for a few seconds to start calibration (see datasheet)
#define DHT11_OUT(state)  LATCbits.LATC4 = state // DHT11 Bi-Directional data pin (see datasheet)
#define DH11_IN           PORTCbits.RC4          // DHT11 Bi-Directional data pin (see datasheet)

#define UART1BUFMAX 10
#define UART2BUFMAX 31
#define PPM_LO_ALM  1000  // CO2 low alarm threshold in parts per million
#define PPM_HI_ALM  4000  // CO2 high alarm threshold in parts per million

// volatile for variables used in interrupt... Also if we dont want the compiler optimising variables "out of scope" when debugging
volatile uint8        UART1BufPtr, UART2BufPtr; // points to where NEXT Rx char will be placed in rxbuf array
volatile uint8        UART1Buf[UART1BUFMAX+1], UART2Buf[UART2BUFMAX+1]; // Array to which UART chars received in interrupt
volatile uint8        CO2Err=0;   // counts number of times we have error on CO2 read and displays error
volatile uint8        DHT11Err=0; // counts number of times we have error on DHT11/22 read and displays error
volatile signed char  status, ProcessTimeout; // described in code explicitly specify as signed to remove compiler warning
volatile signed char  DHT11Data[5]; // Raw DHT11/22 sensor data explicitly specify as signed to remove compiler warning
volatile char         ValStr[6]; // for int/dec to string conversions
volatile char         DegC[3] = { 0xdf, 0x43, 0x00 }; // Degrees C ASCII string (Should be OK but if not check yout default HD44780 font)
volatile char         animation[] = "___________________|___________________";
volatile long         UpTime;   // count seconds since power on
volatile uint16       CO2Value; // CO2 Value returned from MH-Z19


void interrupt high_priority isr(void) // ALL interrupts come here! Keep interrupt code very tight as CPU stack is tiny
{
  static uint8 SecTO = 170; // number of 5.9mS in a second

  if (PIR1bits.RCIF) // interrupt is caused by UART1 RX pin (Data from CO2 Detector)
  {
    UART1Buf[UART1BufPtr] = RCREG1; //read the byte from rx register into receive buffer
    if (UART1BufPtr < UART1BUFMAX) UART1BufPtr++; // inc buffer (if we ever overrun then additional chars dicscarded)
    PIR1bits.RCIF = 0; // acknowledge/clear rx int flag
  }  
  if (INTCONbits.TMR0IF) // timer 0 Overflow (occurs all the time every 5.9mS)
  {
    if(ProcessTimeout) ProcessTimeout--; // dec this timeout until it gets to zero then stop. For timing out of critical loops that may otherwise hang!
    if (!SecTO--)   // every second..
    {
      SecTO = 170;
      UpTime++;
    }
    INTCONbits.TMR0IF = 0; // acknowledge/clr timer0 interrupt
  }
}


void udelay(uint16 count) // short blocking delay (does not need to be accurate as long as >1uS)
{
  while(count--); 
}

void delayms(uint16 ms) // blocking delay of 1mS
{
  while (ms--) udelay(400); // tweek value for 1mS
}

void beep(uint8 freq, uint16 len)
{
  uint16 i;
  for(i=0; i<len; i++)
  {
    BUZZER(1);
    udelay(freq);
    BUZZER(0);
    udelay(freq);
  }  
}

void uinttostr(uint16 val) // convert 16 bit unsigned number to 5 char string
{
  ValStr[5]='\n';
  if(val>10000) { ValStr[4]=val%10+48; val = val/10; } else ValStr[4]='\n';
  if(val>1000)  { ValStr[3]=val%10+48; val = val/10; } else ValStr[3]='\n';
  if(val>100)   { ValStr[2]=val%10+48; val = val/10; } else ValStr[2]='\n';
  if(val>10)    { ValStr[1]=val%10+48; val = val/10; } else ValStr[1]='\n';
  ValStr[0] = val%10+48;
}

void LCD_Write4Bit(uint8 rs, uint8 data, uint16 wait) // write upper nibble to LCD DB4~7 pins (mapped to RB0 - RB3) and add delay
{
  if(rs) LCD_RS(1); else LCD_RS(0); // 1=data / 0=command
  NOP();
  LCD_EN(1);
  if(data&0x10) LCD_D4(1); else LCD_D4(0);
  if(data&0x20) LCD_D5(1); else LCD_D5(0);
  if(data&0x40) LCD_D6(1); else LCD_D6(0);
  if(data&0x80) LCD_D7(1); else LCD_D7(0);
  NOP();
  LCD_EN(0); // data clocked in on low pulse
  udelay(wait); // note the delay value is actually 2.5 x the value passed but thats fine as long as it is over the minimum from the datasheet
}

void LCD_Write8Bit(uint8 rs, uint8 data, uint16 wait) // write a byte of data to the LCD's upper nibble, then lower nibble
{
  LCD_Write4Bit(rs,data,1);       // write upper nibble
  LCD_Write4Bit(rs,data<<4,wait); // shift lower bits to upper bits and to write lower nibble
}

void LCD_WriteStrXY(uint8 col, uint8 line, const char *str) // write string to LCD cursor position (line and col start at 0)
{
  uint8 LineStart[] = {0x00,0x40,0x14,0x54};    // LCD DDRAM Line start addresses
  uint8 address = 0x80 + LineStart[line] + col; // get start position of cursor and set LCD DDRAM address
  LCD_Write8Bit(0,address,10);
	while(*str!='\0') // 2. write out message char by char
	{
    LCD_Write8Bit(1,*str,10);
		str++;
	}  
}

void CLS()
{
  LCD_Write8Bit(0,0x01,1520); // cls (>1.52mS))
}

void LCD_Init() // Init LCD (check you do not have pin 3 connected to a trimmer on the 2004. Got stuck 2 days on that by copy and pasting a bad cct on google)
{
  delayms(100); // HD44780 init takes 40ms note we do not assume a POR assume LCD in indeterminate 4/8 bit mode so need to reset it
  LCD_Write4Bit(0,0x30,4100); // function #1 (and wait >4.1mS)
  LCD_Write4Bit(0,0x30,100);   // function #2 (and wait >100uS))
  LCD_Write4Bit(0,0x30,100);   // function #3 (and wait 100uS - spec-sheet says at this point its reset to 8 bit mode)
  LCD_Write4Bit(0,0x20,38);   // Function control finally set to 4-bit mode. LCD in 4-bit mode now

  delayms(100);  
  LCD_Write8Bit(0,0x28,38);  // Function control enable 2 line (check particular controllers, noted one brand did not work when this line included and only displayed lines 1 and 3!)
  
  LCD_Write8Bit(0,0x0C,1520);  // Display ON / No Cursor (>1.52mS))
  LCD_Write8Bit(0,0x06,38);  // Data mode increment mem after each write
  LCD_Write8Bit(0,0x01,1520); // cls (>1.52mS))
  delayms(500);
}

uint8 ReadCO2()
{
  uint8 cmd[9]={0xff,0x01,0x86,0,0,0,0,0,0x79};
  uint8 i,checksum;

  // CO2 detector is on UART1 so init it  
  if (RCSTA1bits.FERR || RCSTA1bits.OERR) RCSTA1bits.CREN = 0; // clear any UART framing or overrun errors (turn CREN OFF - and on again)
  UART1BufPtr = 0;      // init bufptr back to first position in array
  RCSTA1bits.CREN = 1;  // enable receiving again in case it was disabled for FERR/OERR
  PIE1bits.RCIE = 1;    // enable receive interrupt
  PIR1bits.RCIF = 0;    // clr any spurious rx interrupts (probably not required)

	for(i=0; i<9; i++) // send enqury message to MH-Z19 to read CO2 Sensor
	{
    while (!TXSTA1bits.TRMT); // wait for transmit shift register to become available
    TXREG1 = cmd[i];          // send next cmd
	}
  
  ProcessTimeout = 0xff;  // Give UART Read process around 1.5 seconds to complete, if it isnt done by then this will count down to zero (via interrupt) and we should break critical loops to exit function
  while(UART1BufPtr<9 && ProcessTimeout ); // wait for 9-character transmission from sensor (seriously boz the UART does not need an interrupt, polling would be fine!)
  if(ProcessTimeout==0) return 1; // timed out :-(
    
  if(UART1Buf[0]!=0xff || UART1Buf[1]!=0x86 )  return 2; // bad bits
  checksum=0;
  for(i=1; i<8; i++)  
    checksum = checksum + UART1Buf[i];    
  checksum = 0xff - checksum;
  checksum++;
  if(UART1Buf[8]!=checksum) return 3; // bad checksum
    
  CO2Value = (UART1Buf[2]*256) + UART1Buf[3];  // seems ok so set CO2Value
  return 0; // All Sweet :-)
}

void WaitDHT11ChangeTo(uint8 ToState)
{
  udelay(1); // short delay to get around any rise/time/ringing issues on slower processor which may otherwise trigger immediate exit
  if(ToState==0) 
    while(DH11_IN && ProcessTimeout>0); // line high wait for it to go low
  else
    while(!DH11_IN && ProcessTimeout>0); // line low wait for it to go high
}

uint8 ReadDHT11() // see datasheet/internet/whatever (Same for DHT-22 which is also a better quality sensor) return 0 for good read and non-zero value for error
{
  uint8 i,j,t0,t1;
  uint8 checksum=0;
  uint8 mask = 0x80;

  ProcessTimeout = 0x10;  // Give process a max of around 100mS to complete, if it isnt done by then this will count down to zero (via interrupt) and we should break critical loops to exit function

  // note TMR1 is a free running counter so interrupts wont affect timing
  
  TRISCbits.RC4  = 0; // Set DHT11 port to output/write
  DHT11_OUT(0);       // pull DHT11 pin low to begin read
  delayms(20);        // wait in low state for >18mS to trigger DHT-11 into action
  
  TRISCbits.RC4  = 1; // Set DHT11 port to input/read (DHT-11 will now be in control of the line)
  WaitDHT11ChangeTo(0);  // wait for signal to go low indicating DHT11 activity

  DEBUG(1); // DEBUG is a test macro to set a pin for the logic analyser to trigger on and nothing to do with code logic so can be ignored/removed when encountered
  TMR1=0;
  WaitDHT11ChangeTo(1); // wait for signal to go high (should be around 84uS)
  WaitDHT11ChangeTo(0); // wait for signal to go low and we have started mesurement (should be around 84uS)
  t0 = TMR1; // should be somewhere around 58 (84*2/2.9)
  DEBUG(0);
  if(t0>62) return 1; // preamble timing off
  if(t0<54) return 1; // preamble timing off
  t0=t0>>2; // use t0/4 (or about 42uS) as timing shorter than this is logic '0', loger than this is logic '1'

  // now read the 40 bits of data (5 bytes x 8-bits)
  for(i=0; i<5; i++)
  {  
    DEBUG(1);
    mask=0x80;
    DHT11Data[i]=0;
    for(j=0; j<8; j++) // note we dont really case about the timing of the negative signal
    {  
      WaitDHT11ChangeTo(1);  // wait for low signal to go high and start timer
      TMR1=0;
      WaitDHT11ChangeTo(0); // wait for signal to go low and get timer value to see how wide positive pulse was (remember timer value is in intevals of 2.9uS)
      t1=TMR1;
      if(t1>t0) DHT11Data[i]=DHT11Data[i] | mask; // else set the bit and move mask to next bit
      mask = mask>>1;
    }
    DEBUG(0);
  }
  
  if(ProcessTimeout==0) return 2; // no point in going further as DHT-11 read process hung
  
  checksum = DHT11Data[0] + DHT11Data[1] + DHT11Data[2] + DHT11Data[3];
  if(checksum!=DHT11Data[4]) return 3; // checksum value is bad
  
  return 0; // data good (yipee!))
}

int main()
{
  uint8   i, PollDHT;
  long    ticker;
  uint16  BuzzerSilent=0; // value must be zero for buzzer to sound, when silence button poressed this will be set to value which will count down to zero (in seconds)
  
  // Init PIC18F24K22 Registers, peripherals and I/O Ports (See Microchip datasheet for full descriptions)
  ADCON0 = 0;     // Turn off ADC
  ADCON1 = 0x0F;  // turn off ADC
  ANSELC = 0;     // Turn off ADC
  TRISA  = 0x00;  // PortA: [All Output] (note Port A Not used)
  TRISB  = 0x90;  // PortB: All outputs except for RB4 (Silence Button in) and RB7 (UART2 RX input)
  WPUB   = 0x10;  // Port B pin RB4 weak pull up is enabled (RB4 Alarm Silence pin if grounded)
  TRISC  = 0x90;  // PortC: [All output] except RC4 (DHT11 Humidity sensor input) and RC7 (UART1 RX input)
  
  LCD_EN(0);
  DEBUG(0);
  HI_ALM(0);
  LO_ALM(0);
  BUZZER(0);

  LCD_Init(); 
  LCD_WriteStrXY(0,0,"Roving Dynamics Ltd.");
  LCD_WriteStrXY(0,1,"Open Source Systems");
  LCD_WriteStrXY(0,2,"rodyne.com");
  LCD_WriteStrXY(0,3,"Firmware 2016-09-07");

  RCONbits.IPEN = 0;  // DISABLE PRIORITY INTERRUPTS all use same single ISR (IPEN=0 is actually the default so this line has no effect and left in for comment)
  T0CON = 0xc5;       // (1100 0101) Enable 8 bit TIMER0 overflow interrupt occurs every (fOsc/4) / prescaler / 256  == 11059200/4/64/256 = 5.926...mS
  INTCON = 0x60;      // (0110 0000) enable TIMER0 overflow Interrupt and TURN OFF GLOBAL INTERRUPTS until init finished
  INTCON2 = 0x84;     // (0100 0100) PortB pullups enabled,TIMER0 High priority
  
  T1CON = 0x31;   // (0011 0001) Enable 16 bit timer1 (to measure DHT11 pulses) uses (fOsc/4) and 8 bit prescaler (so tick every 2.8935uS and timer overflows at 189mS)
                  // Note: timer1 counts freely, clear reg on start of pulse and read value at end of pulse to get pulse width (in units of 2.89uS)
  
  UpTime = 0;         // init seconds counter (counter updated by interrupt)

  SPBRGH1 = 0;  // Set UART1 BRG to 9600 baud (Only UART1 used in this version for the MH-Z19)
  SPBRG1 = 17;
  TXSTA1bits.BRGH = 0; // BRGH=0
  TXSTA1bits.TXEN = 1; // TX ENABLED
  TXSTA1bits.SYNC = 0; // Async
  RCSTA1bits.SPEN = 1; // Serial 1 port enabled
  INTCONbits.GIE = 1;  // global interrupts enabled
    
  delayms(5000); // 
  LCD_WriteStrXY(0,0,"CO2 Level   -WAIT-  ");
  LCD_WriteStrXY(0,1,"Temperature -WAIT-  ");
  LCD_WriteStrXY(0,2,"Humidity    -WAIT-  ");
  LCD_WriteStrXY(0,3,"Status      ________");
  delayms(1000); // 

  while(1) // main program loop
  {
    if(ReadCO2()==0) // Read CO2 Sensor and display result as a string 
    {
      LCD_WriteStrXY(0,0,"CO2 Level        ppm");

      if(CO2Value<PPM_LO_ALM-100) status=0;
      if(CO2Value>PPM_LO_ALM) status=2;
      if(CO2Value>PPM_LO_ALM) status=3;

      if(status==0) // normal
      {
        BuzzerSilent=0; // reset this so buzzer will sound on alarm
        LO_ALM(0);      // n turn off lo alarm relay
        HI_ALM(0);      // n turn off hi alarm relay
      }  
      
      if(status==2) LO_ALM(1); // set relay on if exceeds threshold above
      if(status==3) HI_ALM(1); // set relay on if exceeds threshold above
      
      // conv 16 bit number to 5 digit string and display for PPM display (could also include string.h and do it the normal way)
      ValStr[5]='\0';  
      if(CO2Value>=10000) { ValStr[4]=CO2Value%10+48; CO2Value = CO2Value/10; } else ValStr[4]=32;
      if(CO2Value>=1000)  { ValStr[3]=CO2Value%10+48; CO2Value = CO2Value/10; } else ValStr[3]=32;
      if(CO2Value>=100)   { ValStr[2]=CO2Value%10+48; CO2Value = CO2Value/10; } else ValStr[2]=32;
      if(CO2Value>=10)    { ValStr[1]=CO2Value%10+48; CO2Value = CO2Value/10; } else ValStr[1]=32;
      ValStr[0] = CO2Value+48;
      LCD_WriteStrXY(12,0,ValStr);
      CO2Err=0; // sensor reading all good so reset error count
    }
    else
    {  
      if(++CO2Err>9) LCD_WriteStrXY(0,0,"CO2 Level   -ERROR-");
    }  
    
    if(UpTime%3==0) PollDHT=0;
    if(UpTime%3==1 && PollDHT==0) // maximum DHT-11 poll rate is every 3 seconds
    {  
      PollDHT=1;
      if(ReadDHT11()==0) // read DHT11 Temperature/Humidity Sensor and Display
      {
        ValStr[4]=32;
        ValStr[5]='\0';
        // conv high and lo temperature bytes to string (should not be between -9.9 and 99.9 degC so two digits and 1 decimal)
        LCD_WriteStrXY(0,1,"Temperature         ");
        LCD_WriteStrXY(17,1,DegC);
        if(DHT11Data[2]<-10) // format -10 to -40 (ignore decimal) Note you need DHT-22 to get negitive temperatures. DHT-11 only goes from 0-50 degC !!  
        {  
          ValStr[0] = '-';     
          ValStr[1] = DHT11Data[2]/10 + 48;
          ValStr[2] = DHT11Data[2]%10 + 48;
        }  
        else  
        if(DHT11Data[2]<0) // format -9.9  
        {
          ValStr[0] = '-';     
          ValStr[1] = DHT11Data[2]/10 + 48;
          ValStr[2] = '.';
          ValStr[3] = DHT11Data[3]/10 + 48; // only 1 dec place required for temp (sensors not accurate enough for any more)
        }
        else // format 99.9
        {
          if(DHT11Data[2]>=10) { ValStr[1]=DHT11Data[2]%10 +48; DHT11Data[2] = DHT11Data[2]/10; } else ValStr[1]=32;
          ValStr[0] = DHT11Data[2] + 48;
          ValStr[2] = '.';
          ValStr[3] = DHT11Data[3]/10 + 48; // only 1 dec place required for temp (sensors not accurate enough for any more)
        }
        LCD_WriteStrXY(12,1,ValStr);
        
        // conv humidty number to 3 digit percent string (000-100)
        LCD_WriteStrXY(0,2,"Humidity         %RH");
        ValStr[3]=32;
        if(DHT11Data[0]>=100) { ValStr[2]=DHT11Data[0]%10+48; DHT11Data[0] = DHT11Data[0]/10; } else ValStr[2]=32;
        if(DHT11Data[0]>=10)  { ValStr[1]=DHT11Data[0]%10+48; DHT11Data[0] = DHT11Data[0]/10; } else ValStr[1]=32;
        ValStr[0] = DHT11Data[0] + 48;
        LCD_WriteStrXY(12,2,ValStr);
        DHT11Err=0;
      }
      else
      {  
        if(DHT11Err++>9)
        {
          LCD_WriteStrXY(0,1,"Temperature -ERROR- ");
          LCD_WriteStrXY(0,2,"Humidity    -ERROR- ");
        }  
      }      
    }
    
    // display status
    if(ticker%2==0 && status>0) LCD_WriteStrXY(11,3,"         "); // displaying a blank in alternate loop cycles will flash the status
    else if(UpTime<60) LCD_WriteStrXY(11,3," Starting");
    else if(CO2Err>5) LCD_WriteStrXY(11,3," ERROR 1 ");
    else if(DHT11Err>5) LCD_WriteStrXY(11,3," ERROR 2 ");
    else if(status==3) LCD_WriteStrXY(11,3,"CO2 Alarm");
    else if(status==2) LCD_WriteStrXY(11,3,"High CO2");
    else LCD_WriteStrXY(11,3," Normal  ");
    
    if(status==3) // Beep and flash alarm led (note the silent button will set the BuzzerSilent for 1 hour)
    {
      ALM_LED(1); // alarm led on
      if(BuzzerSilent) delayms(500); else beep(500,500); // sound buzzer or do dummy delay if buzzer currently silent
      if(BuzzerSilent) BuzzerSilent--;  // countdown until buzzer resumes
      while(SILENCE_BTN) BuzzerSilent = 3600; // if silence button pressed then turn off buzzer for 1 hour
      ALM_LED(0); // and off
    }
    
    ticker = UpTime;
    while(ticker==UpTime); // wait here for until the second counter to tick over so syncronised to exactly 1 loop per second
    
    CLRWDT(); // This must be actioned within 65 seconds or the PIC watchdog timer will reset the processor
 }
}