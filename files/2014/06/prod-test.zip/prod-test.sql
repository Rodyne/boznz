DROP DATABASE IF EXISTS `prodtest`;
CREATE DATABASE IF NOT EXISTS `prodtest`
USE `prodtest`;


DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `AccountID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AccountType` int(11) unsigned NOT NULL DEFAULT '1',
  `AccountFlags` int(11) unsigned NOT NULL DEFAULT '0',
  `AccountName` varchar(50) DEFAULT NULL,
  `address1` varchar(99) DEFAULT NULL,
  `address2` varchar(99) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `InvoiceCode` varchar(5) DEFAULT NULL,
  `MAFRego` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`AccountID`),
  UNIQUE KEY `id` (`AccountID`),
  UNIQUE KEY `UniqueName` (`AccountName`),
  UNIQUE KEY `MAFLicenceNo` (`MAFRego`),
  KEY `id_2` (`AccountID`),
  KEY `atypeindex` (`AccountType`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=latin1 COMMENT='Companies, Customers, Suppliers, employees, depots etc';

INSERT INTO `account` (`AccountID`, `AccountType`, `AccountFlags`, `AccountName`, `address1`, `address2`, `city`, `Country`, `phone`, `email`, `InvoiceCode`, `MAFRego`) VALUES
	(1, 0, 0, 'Quarantine!', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(261, 32, 2, 'Main Freezer', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MAFREGO'),
	(262, 4, 1, 'The Bank', '', '', '', '', '', '', NULL, NULL),
	(264, 0, 0, '<Please Set>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


DROP TABLE IF EXISTS `assets`;
CREATE TABLE IF NOT EXISTS `assets` (
  `AssetID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `AssetStatus` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '0=disabled, 1=quarantined, 2=active',
  `AssetCode` varchar(16) NOT NULL,
  `PIN` varchar(32) DEFAULT NULL COMMENT 'RFID Fob number or PIN for accessing without PC account',
  `AssetName` varchar(50) NOT NULL,
  `AssetType` char(1) NOT NULL DEFAULT 'P',
  `AssetFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `InfoStr` varchar(250) DEFAULT NULL COMMENT 'Rssource String (Use depends upon asset type)',
  `AuthP` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `AuthS` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `DateStart` date DEFAULT NULL,
  `DateEnd` date DEFAULT NULL,
  `Picture` blob,
  PRIMARY KEY (`AssetID`),
  UNIQUE KEY `AssetCode` (`AssetCode`),
  UNIQUE KEY `AssetName` (`AssetName`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `assets` (`AssetID`, `AssetStatus`, `AssetCode`, `PIN`, `AssetName`, `AssetType`, `AssetFlags`, `InfoStr`, `AuthP`, `AuthS`, `DateStart`, `DateEnd`, `Picture`) VALUES
	(3, 2, 'HELEN', '', 'Helen Brown', 'E', 10, '', 0, 0, NULL, NULL, NULL),
	(4, 2, 'BOZ', '', 'Stephen Brown (Boz)', 'E', 7, '', 99999, 0, NULL, NULL, NULL),
	(6, 0, 'FRED', '', 'Fred Smith', 'E', 122, '123456789', 500, 0, NULL, NULL, NULL);


DROP TABLE IF EXISTS `bags`;
CREATE TABLE IF NOT EXISTS `bags` (
  `BagID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BagMvtRef` int(10) unsigned NOT NULL,
  `FarmNo` varchar(50) DEFAULT NULL,
  `HarvestDate` datetime DEFAULT NULL,
  `WeightKG` decimal(6,2) DEFAULT NULL,
  `WeighDate` datetime DEFAULT NULL,
  PRIMARY KEY (`BagID`),
  UNIQUE KEY `LotPosID` (`BagID`),
  KEY `LotPosID_2` (`BagID`)
) ENGINE=InnoDB AUTO_INCREMENT=305 DEFAULT CHARSET=latin1 COMMENT='Bulk bag information relating to lot';

DROP TABLE IF EXISTS `bom`;
CREATE TABLE IF NOT EXISTS `bom` (
  `BOMID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BOMFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `FinishedProductRef` int(10) unsigned DEFAULT NULL,
  `ReportRef` int(10) unsigned DEFAULT NULL,
  `IngredientRef` int(10) unsigned DEFAULT NULL,
  `Qty` float DEFAULT NULL,
  `BOMUOM` float DEFAULT NULL,
  `ListOrder` tinyint(3) unsigned DEFAULT '0',
  `DefJobInstructions` text,
  PRIMARY KEY (`BOMID`),
  UNIQUE KEY `RecipeID` (`BOMID`),
  KEY `RecipeID_2` (`BOMID`)
) ENGINE=InnoDB AUTO_INCREMENT=182 DEFAULT CHARSET=latin1 COMMENT='Raw material qtys used in finished product';


DROP TABLE IF EXISTS `configuration`;
CREATE TABLE IF NOT EXISTS `configuration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parameter` varchar(50) DEFAULT NULL,
  `KeyName` varchar(50) DEFAULT NULL,
  `value1` text,
  `value2` text,
  `value3` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=latin1 COMMENT='program configuration settings';

INSERT INTO `configuration` (`id`, `parameter`, `KeyName`, `value1`, `value2`, `value3`) VALUES
	(52, 'company', 'name', 'My Company', 'MyAddress', NULL),
	(55, 'delivery-method', NULL, 'Pick-Up / Collection', NULL, NULL),
	(56, 'delivery-method', NULL, 'Refrigerated Container', NULL, NULL),
	(57, 'delivery-method', NULL, 'Courier', NULL, NULL),
	(58, 'fullfillment-status', '10', 'S', 'Draft (Don\'t Produce yet)', NULL),
	(59, 'fullfillment-status', '20', 'S', 'Processing', NULL),
	(60, 'fullfillment-status', '90', 'S', 'Line Complete', NULL),
	(71, 'order-status', '10', 'P', 'Draft', 'N'),
	(72, 'order-status', '20', 'P', 'Raised - Waiting Approval to Buy', 'N'),
	(73, 'order-status', '30', 'P', 'Approved for Buying', 'Y'),
	(74, 'order-status', '40', 'P', 'Ordered Waiting delivery', 'Y'),
	(75, 'order-status', '50', 'P', 'Partially Delivered', 'Y'),
	(76, 'order-status', '60', 'P', 'Delivered in full', 'Y'),
	(77, 'order-status', '90', 'P', 'Complete and Invoice Paid', 'Y'),
	(78, 'order-status', '80', 'P', 'Order cancelled', 'Y'),
	(80, 'currency', 'NZD', 'New Zealand Dollar', 'NZ $', 'Default'),
	(81, 'currency', 'AUD', 'Australian Dollar', 'AU $', NULL),
	(82, 'currency', 'USD', 'US Dollar', 'US $', NULL),
	(83, 'currency', 'EUR', 'Euro', 'E', NULL),
	(84, 'currency', 'HKD', 'Hong Kong Dollar', 'HK $', NULL),
	(86, 'fullfillment-status', '10', 'P', 'Draft', NULL),
	(87, 'fullfillment-status', '20', 'P', 'Waiting Receival', NULL),
	(88, 'fullfillment-status', '90', 'P', 'Receved', NULL),
	(89, 'finance-area', '4', 'Travel / Accomodation', NULL, NULL),
	(90, 'finance-area', '4', 'Stationary / Office Supplies', NULL, NULL),
	(91, 'finance-area', '4', 'Equipment / Plant', NULL, NULL),
	(92, 'finance-area', '4', 'Maintenance Spares', NULL, NULL),
	(93, 'finance-area', '4', 'Advertising', NULL, NULL),
	(94, 'finance-area', '4', 'Entertainment', NULL, NULL),
	(95, 'finance-area', '4', 'Service Charge', NULL, NULL),
	(96, 'finance-area', '4', 'Other Factory Expense', NULL, NULL),
	(97, 'finance-area', '4', 'Other Office Expense', NULL, NULL),
	(98, 'finance-area', '8', 'Delivery Charge', NULL, NULL),
	(99, 'finance-area', '8', 'Stillage Hire', NULL, NULL),
	(100, 'finance-area', '8', 'Container Charge', NULL, NULL),
	(101, 'finance-area', '8', 'Refrigeration/Storage Charge', NULL, NULL),
	(102, 'finance-area', '8', 'Administration', NULL, NULL),
	(103, 'finance-area', '8', 'Additional Levy', NULL, NULL),
	(104, 'finance-area', '4', 'Equipment Hire', NULL, NULL),
	(105, 'finance-area', '4', 'Storage Charges', NULL, NULL),
	(107, 'GSTRate', '20100101', '17.5', 'Put effective date in keyname YYYMMDD', NULL),
	(108, 'order-status', '10', 'S', 'Draft', 'N'),
	(109, 'order-status', '20', 'S', 'Raised - Waiting Approval to Produce', 'N'),
	(110, 'order-status', '30', 'S', 'Approved for Production', 'Y'),
	(111, 'order-status', '40', 'S', 'Production in Progress', 'Y'),
	(112, 'order-status', '50', 'S', 'Partially Delivered', 'Y'),
	(113, 'order-status', '60', 'S', 'Delivered in full', 'Y'),
	(114, 'order-status', '80', 'S', 'Complete and Invoice Paid', 'Y'),
	(115, 'order-status', '90', 'S', 'Order Cancelled', 'Y'),
	(116, 'bag-status', '10', 'New / Received', NULL, NULL),
	(117, 'bag-status', '20', 'Active / Part Processed', NULL, NULL),
	(118, 'bag-status', '30', 'Complete / Waiting Accounts', NULL, NULL),
	(119, 'bag-status', '90', 'Complete', NULL, NULL),
	(124, 'country', 'NZ', 'New Zealand', NULL, NULL),
	(125, 'country', 'AU', 'Australia', NULL, NULL),
	(126, 'country', 'FJ', 'Fiji', NULL, NULL),
	(127, 'country', 'EU', 'European Union', NULL, NULL),
	(128, 'country', 'UK', 'United Kingdom', NULL, NULL),
	(129, 'country', 'US', 'United States', NULL, NULL),
	(130, 'country', 'JP', 'Japan', NULL, NULL),
	(131, 'country', 'KO', 'Korea', NULL, NULL),
	(132, 'country', 'CN', 'China', NULL, NULL),
	(133, 'country', 'TH', 'Thailand', NULL, NULL),
	(134, 'country', 'VI', 'Vietnam', NULL, NULL),
	(135, 'country', 'MA', 'Malaysia', NULL, NULL),
	(136, 'country', 'SI', 'Singapore', NULL, NULL),
	(137, 'country', 'IN', 'Indonesia', NULL, NULL),
	(138, 'country', 'PH', 'Philippines', NULL, NULL),
	(139, 'country', 'CA', 'Canada', NULL, NULL),
	(140, 'country', 'RU', 'Russia', NULL, NULL),
	(141, 'country', 'IN', 'India', NULL, NULL),
	(142, 'country', 'SA', 'Saudi Arabia', NULL, NULL),
	(143, 'country', 'OM', 'Oman', NULL, NULL),
	(144, 'country', 'UA', 'UAE', NULL, NULL);

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `JobID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `LineItemRef` int(11) DEFAULT NULL,
  `JobType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `JobStatus` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `JobInstructions` text,
  `JobLog` text,
  `DateTimeIssued` datetime DEFAULT NULL,
  `DateTimeCompleted` datetime DEFAULT NULL,
  `IssuerRef` int(11) DEFAULT NULL,
  `SignoffRef` int(11) DEFAULT NULL,
  PRIMARY KEY (`JobID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `lineitems`;
CREATE TABLE IF NOT EXISTS `lineitems` (
  `LineItemID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ProductItemRef` int(11) DEFAULT NULL,
  `ItemStatus` int(11) NOT NULL DEFAULT '0',
  `QtyUom` int(11) NOT NULL DEFAULT '0',
  `ItemFlags` int(11) NOT NULL DEFAULT '0',
  `Instructions` text,
  `log` text,
  `CompletionDate` datetime DEFAULT NULL,
  `OrderQty` mediumint(8) unsigned DEFAULT NULL,
  `CostEa` decimal(10,3) unsigned DEFAULT NULL,
  `GSTRate` decimal(10,3) unsigned NOT NULL DEFAULT '0.000',
  `DeliveryDate` date DEFAULT NULL,
  `DeliveryContact` varchar(50) DEFAULT NULL,
  `DeliveryMethod` varchar(50) DEFAULT NULL,
  `LabelType` varchar(50) DEFAULT NULL,
  `OrderRef` int(11) NOT NULL,
  PRIMARY KEY (`LineItemID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `mobile`;
CREATE TABLE IF NOT EXISTS `mobile` (
  `UID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `IPAddress` varchar(50) NOT NULL DEFAULT '0.0.0.0',
  `AssignedUser` int(11) DEFAULT NULL,
  `FormNo` int(11) NOT NULL DEFAULT '0',
  `JobID` int(11) DEFAULT NULL,
  `AssetID` int(11) DEFAULT NULL,
  `ProgramRef` tinyint(3) unsigned DEFAULT NULL COMMENT 'Use ReportID as reference with program code that will be downloaded to terminal on connect',
  `SessionLog` text,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `movements`;
CREATE TABLE IF NOT EXISTS `movements` (
  `MovementID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ProductRef` int(11) DEFAULT NULL,
  `JobRef` int(11) DEFAULT NULL,
  `MvtItemRef` int(11) DEFAULT NULL,
  `MvtType` tinyint(3) unsigned DEFAULT NULL,
  `MvtFlags` smallint(5) unsigned NOT NULL DEFAULT '0',
  `EstQty` decimal(10,3) DEFAULT NULL,
  `ActualQty` decimal(10,3) DEFAULT NULL,
  `MvtUOM` int(11) DEFAULT NULL,
  `StockLocnRef` int(11) DEFAULT NULL,
  `AccountFrom` int(11) DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `CreationDate` datetime NOT NULL,
  `CompletedBy` int(11) DEFAULT NULL,
  `CompletionDate` datetime DEFAULT NULL,
  `LotCode` varchar(50) DEFAULT NULL,
  `ConsignmentNo` varchar(50) DEFAULT NULL,
  `TransportRego` varchar(50) DEFAULT NULL,
  `Comment` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`MovementID`),
  UNIQUE KEY `LotCode` (`LotCode`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `OrderID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `OrderDate` date NOT NULL,
  `RaisedBy` int(11) DEFAULT NULL,
  `ApprovedBy` int(11) DEFAULT NULL,
  `ApprovedAmt` int(11) unsigned NOT NULL DEFAULT '0',
  `AccountRef` int(10) unsigned DEFAULT NULL,
  `OrderContact` varchar(100) DEFAULT NULL,
  `CustPONum` varchar(50) DEFAULT NULL,
  `OrderType` enum('P','S') DEFAULT 'P',
  `LabelType` int(11) NOT NULL DEFAULT '0',
  `DeliveryAddress` varchar(500) DEFAULT NULL,
  `InvoiceAddress` varchar(500) DEFAULT NULL,
  `OrderTotal` decimal(8,2) DEFAULT NULL,
  `OrderStatus` tinyint(3) unsigned DEFAULT '0',
  `OrderFlags` tinyint(3) unsigned DEFAULT '0',
  `CurrencyUnit` varchar(3) DEFAULT 'NZD',
  `OrderText` text,
  `OrderLog` text,
  PRIMARY KEY (`OrderID`),
  UNIQUE KEY `OrderID` (`OrderID`),
  KEY `OrderID_2` (`OrderID`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1 COMMENT='delivery and purchase orders';

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `ProductID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(99) DEFAULT NULL,
  `ProductGroup` varchar(99) DEFAULT NULL,
  `ProductFlags` mediumint(9) NOT NULL DEFAULT '1',
  `ProductClass` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `EAN` varchar(13) DEFAULT NULL,
  `cost` decimal(9,2) DEFAULT NULL,
  `ProductUOM` varchar(15) NOT NULL DEFAULT '0',
  `WeightKg` decimal(12,6) DEFAULT NULL,
  `comment` text,
  `Warnings` text,
  `DeliveryDays` tinyint(3) unsigned NOT NULL DEFAULT '5',
  `MinOrderQty` int(10) unsigned NOT NULL DEFAULT '1',
  `LotCodeTemplate` text,
  `ChangeLog` text,
  PRIMARY KEY (`ProductID`),
  UNIQUE KEY `ProductID` (`ProductID`),
  UNIQUE KEY `ProductName` (`ProductName`),
  KEY `ProductID_2` (`ProductID`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=latin1 COMMENT='Product Master table';

DROP TABLE IF EXISTS `reports`;
CREATE TABLE IF NOT EXISTS `reports` (
  `ReportID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ReportTitle` varchar(250) NOT NULL DEFAULT 'New Report',
  `ReportArea` varchar(250) NOT NULL DEFAULT 'General',
  `Permissions` mediumint(9) NOT NULL DEFAULT '-1',
  `ReportCount` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `ReportFlags` smallint(5) unsigned NOT NULL DEFAULT '0',
  `LastRun` varchar(50) NOT NULL DEFAULT 'Never',
  `QuerySQL` mediumtext,
  `ReportLayout` mediumtext,
  PRIMARY KEY (`ReportID`),
  UNIQUE KEY `ReportTitle` (`ReportTitle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `uom`;
CREATE TABLE IF NOT EXISTS `uom` (
  `UOMID` tinyint(3) unsigned NOT NULL,
  `UnitName` varchar(50) NOT NULL,
  `BaseUnit` varchar(10) NOT NULL,
  `xFactor` float NOT NULL,
  `UOMFlags` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`UOMID`),
  UNIQUE KEY `UnitName` (`UnitName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `uom` (`UOMID`, `UnitName`, `BaseUnit`, `xFactor`, `UOMFlags`) VALUES
	(1, 'Kg', 'Kg', 1, 3),
	(2, 'g', 'Kg', 1000, 2),
	(5, 'L', 'L', 1, 3),
	(6, 'mL', 'L', 1000, 2),
	(7, 'Items', 'Items', 1, 3),
	(10, 'Packets', 'Items', 1, 2),
	(11, 'Pouches', 'Items', 1, 2),
	(12, 'Cartons', 'Items', 1, 2);