-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.2-m5 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             8.1.0.4545
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for mobile
DROP DATABASE IF EXISTS `mobile`;
CREATE DATABASE IF NOT EXISTS `mobile` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `mobile`;


-- Dumping structure for table mobile.mobiledevices
DROP TABLE IF EXISTS `mobiledevices`;
CREATE TABLE IF NOT EXISTS `mobiledevices` (
  `DeviceID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IPAddress` varchar(50) NOT NULL DEFAULT '0.0.0.0',
  `ConfigStr` varchar(99) DEFAULT '' COMMENT 'SCR=128x128x2,KEYPAD=1,RFID=125,BARCODE=1,ROM=256,RAM=64',
  `AssignedApp` int(11) DEFAULT NULL,
  `AssignedUser` varchar(20) DEFAULT NULL,
  `LastPing` timestamp NULL DEFAULT NULL,
  `SessionLog` text,
  `DeviceLog` text,
  PRIMARY KEY (`DeviceID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.


-- Dumping structure for table mobile.mobilequeries
DROP TABLE IF EXISTS `mobilequeries`;
CREATE TABLE IF NOT EXISTS `mobilequeries` (
  `QID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `QueryType` char(3) NOT NULL DEFAULT 'GET',
  `QueryActive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `QueryDesc` varchar(99) DEFAULT NULL,
  `FunctionCode` tinyint(3) unsigned DEFAULT NULL,
  `QueryCode` text,
  `InputFieldCount` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `OutputFieldCount` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ReportFormat` text,
  PRIMARY KEY (`QID`),
  UNIQUE KEY `FunctionCode` (`FunctionCode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
