/*
2016 Roving Dynamics Ltd. (rodyne.com)
Description: Vinwizard 4-Channel PT100 Temperature Sensor and 8 Ch relay IO Controlled by RPI
Prepared for Wine Technologies (winetec.us)
Licence: LGPL
Target MPU =  PIC16F1782/3 (12 bit ADC) using Internal clk @ 8Mhz
Firmware Rev: 1.2 (Aug 2016)
*/

#include <xc.h>

#define uint8		unsigned char
#define uint16	unsigned short
#define int16   short

#pragma config FOSC     = INTOSC	// Use internal OSC
#pragma config PLLEN    = OFF     // No PLL
#pragma config CLKOUTEN = 1       // Dont want Clk out
#pragma config WDTE     = ON      // Watchdog timer ON
#pragma config BOREN    = ON      // Turn on Brown-out reset so the device resets on any power problem
#pragma config STVREN   = ON      // Stack Overflow/Underflow Reset Enable (Stack Overflow or Underflow will cause a Reset)

// *** Macros for PIC16 digital output pins, no digital inputs defined (changes to pin mappings here may also require change to TRIS in program startup!)

#define CTRL1(state)    LATAbits.LATA2 = state // Output - Relay1 (RC7 in Ver3))
#define CTRL2(state)    LATAbits.LATA3 = state // Output - Relay2
#define CTRL3(state)    LATAbits.LATA4 = state // Output - Relay3
#define CTRL4(state)    LATBbits.LATB1 = state // Output - Relay4
#define CTRL5(state)    LATBbits.LATB5 = state // Output - Relay5
#define CTRL6(state)    LATBbits.LATB4 = state // Output - Relay6
#define CTRL7(state)    LATBbits.LATB3 = state // Output - Relay7
#define CTRL8(state)    LATBbits.LATB2 = state // Output - Relay8
#define PWR5V(state)    LATCbits.LATC7 = state // Output - Enable 5V PSU FOR RPi
#define SEL0(state)     LATCbits.LATC0 = state // Output - Analog MUX Select A0
#define SEL1(state)     LATCbits.LATC1 = state // Output - Analog MUX Select A1
#define SEL2(state)     LATCbits.LATC2 = state // Output - Analog MUX Select A2
#define PWRDNSIG(state) LATCbits.LATC3 = state // Output - Tells the RPi operating system that a power down is imminent (so shutdown now if you can!)
#define ACT_LED(state)	LATCbits.LATC4 = state // Output - LED1 shows I2C Activity
#define ERR_LED(state)	LATCbits.LATC5 = state // Output - LED2 shows rpi has been reset and is currently in error
#define BUZZER(state)   LATCbits.LATC6 = state // Output - BUZZER: Hi=OFF or 1Khz Square wave to make noise!

#define I2C_ADDR (0x05<<1)  // I2C Address = 5. Note I2C address is 7 bits and LSB not used thats why we shift left.
#define MAXREG	 40         // Num of I2C registers this slave will expose to the raspberry pi (see below for description of each))

#define XMODE  	I2CREG[0]   // Bit 0 = Temperature Output mode register: 
                            //    0 == Register is Raw ADC value (Default) - Keep this if u want to do the temperature calculations yourself in the RPi
                            //    1 == register is temperature in MLP format  ie Temp (DegC) = (RegValue/20) - 40  (eg RegValue = 800 == 0.0DegC, 1234 = 21.7DegC)
                            // bit 1 reserved
                            // Bits 2:3 = RPi Watchdog timer mode:
                            //    00 = OFF. RPi will not power cycle on no I2C comms (Default) - (for debugging so first thing your RPi program should do is set this)
                            //    01 = RPi will power cycle/reset if I2C Comms not received within 4 minutes
                            //    10 = RPi will power cycle/reset if I2C Comms not received within 16 minutes
                            // Bits 4:5 = Continuous fail mode (If above active):
                            //    00 = RPi will power-off/reset upto 4 times then power on Rpi and sound alarm (Default)
                            //    01 = RPi will power-off/reset upto 8 times then power on Rpi and sound alarm
                            //    10 = RPi will power-off/reset upto 16 times then power on Rpi and sound alarm
                            //    (Note each power off will be 4 seconds longer than the last as more failures occur, eg 1st failure will be 4 seconds, second will be 8 seconds, 12, 16 .. up to a minute)  
                            // bits 6 and 7 reserved
                            // registers 1+2   (ch0) 16-bit pt100 temperature sensors #1
                            // registers 3+4   (ch1) 16-bit pt100 temperature sensors #2
                            // registers 5+6   (ch2) 16-bit pt100 temperature sensors #3
                            // registers 7+8   (ch3) 16-bit pt100 temperature sensors #4
                            // registers 9+10  (ch4) 16-bit Lo Calibration Resistor ADC Output
                            // registers 11+12 (ch5) 16-bit Hi Calibration Resistor ADC Output
                            // registers 13+14 (ch6) 16-bit Lo Calibration Resistor ADC Output
                            // registers 15+16 (ch7) 16-bit Hi Calibration Resistor ADC Output
                            // registers 17-20 reserved
#define RLA1		I2CREG[21]  // RLA1: 0 = Relay Off, >0 = Relay On
#define RLA2		I2CREG[22]  // RLA2: 0 = Relay Off, >0 = Relay On
#define RLA3		I2CREG[23]  // RLA3: 0 = Relay Off, >0 = Relay On
#define RLA4		I2CREG[24]  // RLA4: 0 = Relay Off, >0 = Relay On
#define RLA5		I2CREG[25]  // RLA5: 0 = Relay Off, >0 = Relay On
#define RLA6		I2CREG[26]  // RLA6: 0 = Relay Off, >0 = Relay On
#define RLA7		I2CREG[27]  // RLA7: 0 = Relay Off, >0 = Relay On
#define RLA8		I2CREG[28]  // RLA8: 0 = Relay Off, >0 = Relay On
                            // Registers 29-36 reserved
#define UPTIMEL I2CREG[37]  // Uptime low byte
#define UPTIMEH I2CREG[38]  // Uptime high byte
#define STATUS  I2CREG[39]  // Status Register (Bit 0 = Ready set to 1 when DAC/ADC calibrated and done a full poll)

// Global variables. volatile if read/written in interrupt and/or want to see in debugger

volatile uint8  I2CREG[MAXREG];       // I2C REGISTERS in RAM (See register descriptions above)
volatile uint8  data,RegPtr,SetAddr;  // Other globabl variables
volatile uint8  PiFailCtr = 0;        // number of times we have power cycled the pi without comms
volatile uint16 WDTPi = 0;            // number of times we have power cycled the pi without comms

uint8  MuxCh;      // which pt100 mux channel is currently selected as input to ADC (0..7))
uint16 ADC[8];     // ADC raw values for temp calcualtions
long   val32;      // 32 bit long value for temp calculations


void interrupt  I2C_Slave_Read() // I2C interrupts come here!
{
  if(SSP1IF == 1)
  {    
    if (SSP1STATbits.R_nW == 1) // Read register data
    {
      WDTPi = 0; // After an I2C read Reset pi Watchdog timer and fail counter
      PiFailCtr = 0;
      if(RegPtr<MAXREG) SSP1BUF = I2CREG[RegPtr++]; else SSP1BUF = 0xff; // if Register Address valid then send its data to master else send 0xff
    }
    
    if (SSP1STATbits.R_nW == 0)  //  Write register data or set register address
    {
      if (SSP1STATbits.D_nA == 1) // Last byte was data
      {
        if (SetAddr) // first byte received after the I2C address is the register address
        {
          RegPtr = SSP1BUF; // set array address ptr
          SetAddr = 0;   // flag address set
        }
        else
        {
          if(RegPtr<MAXREG) I2CREG[RegPtr++] = SSP1BUF; // set register if in value (all registers are read/write though some dont make sense to write to)
        }
      }
      if (SSP1STATbits.D_nA == 0) // Last byte was an address, so next thing written will be the register address
      {
          SetAddr = 1;   //last byte was address, next will be data location
          data = SSP1BUF;   // read buffer
      }
    }
    
    if(BF) data = SSPBUF; // if buffer still full then read out any data to clear it, shouldnt happen but best to be safe
    
    if (SSPCONbits.SSPOV || SSPCONbits.WCOL) // clear any error conditions
    {      
      SSPCONbits.SSPOV = 0; // Clear the overflow flag
      SSPCONbits.WCOL = 0;  // Clear the collision bit
    }
    
    SSP1IF = 0; // clear SSPIF flag bit
    SSPCONbits.CKP = 1; // Always ensure CLK Released (not using it here as processing is v fast but just in case I do..)
  }
}

void delay(uint16 ms) // blocking delay of approx 1000uS (1mS) doesnt need to be accurate
{
  uint16 i;
  while (ms--)
  {
    CLRWDT();     // ping PIC16 internal WDT Here as it is called in every loop/wait fn (Not the same as the Pi WDT)
    i = 200;
    while (i--);  // inner delay loop initial value of i is tweeked for delay of approx 1000uS @ Fosc
  }  
}

void HaltAndWaitForI2C() // relays off and stop processing until I2C Signal received
{
  CTRL1(0);
  CTRL2(0);
  CTRL3(0);
  CTRL4(0);
  CTRL5(0);
  CTRL6(0);
  CTRL7(0);
  CTRL8(0);
  while(PiFailCtr) // keep buzzing until I2C received and drop out of loop
  {            
    BUZZER(1);
    delay(2);
    BUZZER(0);
    delay(2);
  }
}  

void ResetRPi() // Turn off and on the 5V power to the raspberry pi
{
  uint16 PwrOffDelay;

  if(++PiFailCtr<16) PwrOffDelay = 4000 * PiFailCtr; else PwrOffDelay=0xffff; // progressively increase time RPi remains off each reboot

  ERR_LED(0);
  ACT_LED(1);
  PWRDNSIG(1);  // Send a power down signal to RPi
  delay(10000); // wait 10 seconds for OS to shutdown if possible
  PWR5V(0);     // power off the 5V to the RPi
  ERR_LED(1);
  ACT_LED(0);
  SSPEN = 0;
  SSP1IE  = 0;  // Turn off serial peripheral interrupts during power outage
  GIE=0;
  delay(PwrOffDelay); // leave power off for progressively longer each failure (might do something!))

  // then reset the I2C just in case it was this PCB which caused problems
  ACT_LED(1);
  SSPCON1 = 0x36; // I2C Enabled + I2C Slave mode 7 bit addressing
  SSPCON2 = 0x01;  
  SSPCON3 = 0x00; 
  GIE     = 1;    // enable global interrupts
  SSP1IF  = 0;    // Clear the serial peripheral interrupt flag
  SSP1IE  = 1;    // Enable serial peripheral interrupts

  PWRDNSIG(0);    // reset power down signal to RPi
  PWR5V(1);       // power RPi back on and reset watchdog while it boots up
  WDTPi = 0;
  if(XMODE & 0x30==00 && PiFailCtr>4)  HaltAndWaitForI2C();
  if(XMODE & 0x10 && PiFailCtr>8)  HaltAndWaitForI2C();
  if(XMODE & 0x20 && PiFailCtr>16) HaltAndWaitForI2C();
 }  

void SelectMuxCh(uint8 ch) // Set MuxCh and physical address lines for that channel
{
  MuxCh=ch;
  if(ch&0x01) SEL0(1); else SEL0(0);
  if(ch&0x02) SEL1(1); else SEL1(0);
  if(ch&0x04) SEL2(1); else SEL2(0);
}

void OptimiseVRef() // Set Vref to give Optimal FSD
{
  SelectMuxCh(7); // Select Hi Calibrate resistor Channel 7 (124 ohm)
  DACCON1 = 40;   // Set DAC to starting Vref
  do // increase Vref gradually until Full Scale Deflection is close to top of our ADC (dont go right to top as it may clip!)
  {
    if(DACCON1%2) ACT_LED(1); else ACT_LED(0); // light show
    if(DACCON1%2) ERR_LED(0); else ERR_LED(1); // light show
    DACCON1++;    // set vref
    delay(250);   // wait for voltage to settle
    ADGO = 1;     // start ADC conversion on AN0
    while(ADGO);  // wait for Conversion to complete
  }  
  while(ADRES<3800 || ADRES>4000); // Read ADC. 4096 is FSD on the 12-bit ADC so aim slightly lower so we dont clip
  SelectMuxCh(0); // reset channel selection
}

void ReadPT100() // read ADC, do temp conversion if required and populate seleted I2C reg
{
  uint16 x = 0; // general purpose variable
  val32 = 0;
  for(x=0; x<64; x++) // take average several 12-bit samples using accumulator (helps reduce remaining noise)
  {  
    ADGO = 1;      // start conversion on AN0
    while(ADGO);   // wait for Conversion to complete
    val32 = val32 + ADRES; // accumulate samples to avg
  }  
  ADC[MuxCh] = val32 / 4; // As we are using relative ADC values in calculation we dont actually need the proper average (ie div by 64) just to bring value back to 16 bit value
  
  if(STATUS&0x01) // Only change I2C temperature registers after complete a pass
  {
    if(XMODE & 0x01) // if this bit is set then convert ADC to temp in MLP Format using calib resistors as reference points
    {
      // calculte the real temperature using: Real Temp (DegC) = (ADC[MuxCh]-ADC[6])*74/(ADC[7]-ADC[6]) - 12
      // For temp calculations mux channel 6 is our calibratrion 95.3 ohm resistor = -12 DegC, channel 7 is our calibratrion 124 ohm resistor = +62 DegC 
      // 74 DegC is the diff.  because we know two fixed temperature points and there ADC values we can calculate any temp in between by knowing its ADC value.      
      val32 = ADC[MuxCh] - ADC[6];
      val32 = val32 * 74;
      x = ADC[7] - ADC[6];
      // Convert MLP format using MLPValue = (Temp + 40) x 20 (equation below incorporates the -12 offset and is modified to be a bit more accurate using integer math)
      val32 = (val32 * 20) / x;
      val32 = val32 + 560;
      I2CREG[MuxCh*2+1] = val32;
      I2CREG[MuxCh*2+2] = val32 >> 8;
    }
    else // bit not set then just output ADC Value and let RPi program do the conversion
    {      
      I2CREG[MuxCh*2+1] = ADC[MuxCh];
      I2CREG[MuxCh*2+2] = ADC[MuxCh] >> 8;
    }
  }  
  if(++MuxCh>7) // goto next channel and once we get beyond last channel start again at channel 0
  {
    SelectMuxCh(0);
    STATUS=STATUS|0x01; // Set READY bit once we done a reading on each channel
  }
  else
    SelectMuxCh(MuxCh);
}

int main()
{
  uint16 HrCtr = 0; // counts out an hour for our hour counter
  uint8  i;         // general purpose variable

  // Init PIC16F1783 Registers, peripherals and I/O Ports (Bit complicated. Read Microchip datasheet/Internet/whatever for full descriptions)
  
  OSCCON  = 0x70; // Use Internal Oscilator @ 8Mhz 
  TRISA   = 0x23; // PortA: [All Output] except RA0 (ADC In) and RA1 (VRef Out Via the OPAMP AND DAC) AND RA5 (Op Amp -Ve Input)
  TRISB   = 0xC0; // PortB: All output except RB6 and RB7 which are I2C (check!)
  TRISC   = 0x00; // PortC: All output
  
  BUZZER(1);      // Turn off buzzer
  PWRDNSIG(0);    // Turn off power down signal to RPi
  PWR5V(0);       // Turn off the RPI 5V power wait for init to complete (or about a second)
  
  APFCON  = 0x18; // Move I2C to alternative pins RB6 (SDA) and RB7 (SCL)
  T1CON   = 0x31; // Enable 16 bit timer1 uses (fOsc/4) and 8 bit prescaler (timer1 overflow flag set after approx 256mS @ 8Mhz)
  FVRCON  = 0xAA; // Enable FVR (Fixed Voltage Ref) Set to 2.048V for both DAC and ADC, internal temp sensor active on low range
  ADCON1  = 0xa3; // Select internal Vref, slow clock (we working at 8Mhz so use Fosc/32) 2's compliment format
  ADCON2  = 0x0f; // PIC Uses differential ADC by default, must be changed to single ended ie -ve input is tied to GND
  ANSELA  = 0x01; // Only Analog 1 input is enabled/used
  ADCON0  = 0x01; // Set ADC to 12 bit, Select Channel 0 (AN0) and Turn On
  DACCON0 = 0x88; // Enable DAC using internal Vref (2.048V) output to pic internal opamp1
  OPA1CON = 0x82; // Enable OpAmp1 then use input from DAC

  for (i = 0; i < MAXREG; i++) I2CREG[i] = 0;  // init slave I2C registers

  OptimiseVRef(); // adjust reference voltage on calibration resistor to optimise ADC range
  
  WDTCON = 0x23;  // now switch on the PICs internal watchdog timer so if our main loop fails for more than 128 seconds then reset the PIC
  
  // Init slave I2C communications and interrupts
  SSPADD  = I2C_ADDR;
  SSPBUF  = 0x00;
  SSPSTAT = 0x00;
  SSPCON1 = 0x36; // I2C Enabled + I2C Slave mode 7 bit addressing
  SSPCON2 = 0x01;  
  SSPCON3 = 0x00; 

  GIE     = 1;    // enable global interrupts
  PEIE    = 1;    // enable peripheral Interrupts (I2C))
  SSP1IF  = 0;    // Clear the serial peripheral interrupt flag
  SSP1IE  = 1;    // Enable serial peripheral interrupts
  
  PWR5V(1);   // Finally Turn on the RPI 5V power 
  
  while (1) // main program loop
  { 
    TMR1IF=0; // clr the timer interrupt flag or program will end at final while(TMR1F) statement
    
    ACT_LED(0); // turn off activity led
    ERR_LED(0); // turn off error led
    
    if ( ++WDTPi<2 ) ACT_LED(1);        // flash I2C Packet recently recieved
    if ( WDTPi>100 && HrCtr%2 ) ERR_LED(1); // flash error if I2C Comms failure in progress! (nothing received for 30 seconds or more)

    if(HrCtr%2) ReadPT100(); // read ADC and store temp in I2C register

    // set the relays
    if(RLA1) CTRL1(1); else CTRL1(0);
    if(RLA2) CTRL2(1); else CTRL2(0);
    if(RLA3) CTRL3(1); else CTRL3(0);
    if(RLA4) CTRL4(1); else CTRL4(0);
    if(RLA5) CTRL5(1); else CTRL5(0);
    if(RLA6) CTRL6(1); else CTRL6(0);
    if(RLA7) CTRL7(1); else CTRL7(0);
    if(RLA8) CTRL8(1); else CTRL8(0);

    // inc hour counter. Stops when it gets to 0xffff (about 7.4 years) WOW that would be so awesome should get the RPi to play yankee-doodle-dandy or something!
    if (++HrCtr > 13043 &&  UPTIMEH<0xff &&  UPTIMEL<0xff)
    {        
      if(++UPTIMEL==0) UPTIMEH++; 
      HrCtr=0;
    }

    if(XMODE & 0x04 && WDTPi>1000) ResetRPi(); // MODE 01 = RPi will power cycle/reset if I2C Comms not received within 4 minutes
    if(XMODE & 0x08 && WDTPi>4000) ResetRPi(); // MODE 10 = RPi will power cycle/reset if I2C Comms not received within 16 minutes

    while(!TMR1IF); // wait for timer overflow (256mS since TMR1IF was reset)
  }
}