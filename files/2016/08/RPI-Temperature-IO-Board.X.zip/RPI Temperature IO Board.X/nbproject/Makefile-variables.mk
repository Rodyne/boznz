#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=RPI_Temperature_IO_Board.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/RPI_Temperature_IO_Board.X.production.hex
CND_PACKAGE_DIR_default=${CND_DISTDIR}/default/package
CND_PACKAGE_NAME_default=rpitemperatureioboard.x.tar
CND_PACKAGE_PATH_default=${CND_DISTDIR}/default/package/rpitemperatureioboard.x.tar
