/* 
 * Raspberry Pi USB Real-time-clock 
 * 
 * Connects to USB and enumerates as a serial port at 115200 baud
 * sending S=YYYY-MM-DD HH:MM:SS will set the clock and sending 
 * any other key combination will return the date/time in format
 * YYYY-MM-DD HH:MM:SS
 * 
 * The majority of this file and all other included files are a
 * Modification of the M-Stack USB Device Stack * 
 * Copyright (C) 2013 Alan Ott <alan@signal11.us>
 * Copyright (C) 2013 Signal 11 Software. * 
 * Thanks to Alan for cotributing these files to the open source
 * community and see those files for more information on how to 
 * obtain the source and how to use it.
 * 
 * This is FREE software feel free to modify or re-use 
*/

#pragma config FOSC = INTOSC
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config MCLRE = ON
#pragma config CP = OFF
#pragma config BOREN = ON
#pragma config CLKOUTEN = OFF
#pragma config IESO = OFF
#pragma config FCMEN = OFF
#pragma config WRT = OFF
#pragma config CPUDIV = NOCLKDIV
#pragma config USBLSCLK = 48MHz
#pragma config PLLMULT = 3x
#pragma config PLLEN = ENABLED
#pragma config STVREN = ON
#pragma config BORV = LO
#pragma config LPBOR = ON
#pragma config LVP = OFF

#include "usb.h"
#include <xc.h>
#include <string.h>
#include "usb_config.h"
#include "usb_ch9.h"
#include "usb_cdc.h"

static struct cdc_line_coding line_coding = { 115200, CDC_CHAR_FORMAT_1_STOP_BIT, CDC_PARITY_NONE, 8 };

#define _XTAL_FREQ          (48000000UL) // 3 x 16Mhz - 48Mhz
#define ACT_LED(state)      LATCbits.LATC4 = !state // Output - LED1 shows I2C Activity
#define DS1307ReadAddress   0xD1
#define DS1307WriteAddress  0xD0

const char    help[] = 
"USB Real-Time-Clock: 2017 Roving Dynamics Ltd. (rodyne.com)\r\n\r\n\
(Hardware and Firmware are Public Domain goto rodyne.com for source)\r\n\r\n\
  Send 'F' Character to receive RTC data formatted:   YYYY-MM-DD HH:MM:SS\r\n\
  Send 'U' Character to receive RTC data unformatted: YMDWHMS\r\n\
       (BCD Packed Format - ie registers 0..6 of DS1307 chip)\r\n\
  Send 'S=YYMMDDHHMMSS' followed by a CR to set datetime.\r\n\
  Send 'SB=YMDWHMS' followed by a CR to set datetime in BCD Format.\r\n\
       (BCD Packed Format - ie registers 0..6 of DS1307 chip)\r\n\r\n";
const char    err[9][23] = // error messages
{
  "?                   \r\n",
  "\r\nFormatting Error 1\r\n",
  "\r\nError 2 Year Bad  \r\n",
  "\r\nError 3 Month Bad \r\n",
  "\r\nError 4 Day Bad   \r\n",
  "\r\nError 5 DOW Bad   \r\n",
  "\r\nError 6 Hour Bad  \r\n",
  "\r\nError 7 Mins Bad  \r\n",
  "\r\nError 8 Secs Bad  \r\n",
};
char    td[30]    = "20YY-MM-DD HH:MM:SS00000000\r\n"; // buffer to form time before display
uint8_t *RXData, *TXData; // buffers for usb/cdc transfers
uint8_t I2CBuf[10],KeyBuf[15]; // buffers for DS1037 reg transfers and input
int     RXLen,led;

void interrupt isr()
{
  usb_service();
}

void I2C_Wait()
{
  while ((SSPSTAT & 0x04) || (SSPCON2 & 0x1F)); //Transmit is in progress
}

void I2CStart()
{
  I2C_Wait();    
  SEN = 1;             //Initiate start condition
}

void I2CStop()
{
  I2C_Wait();
  PEN = 1;           //Initiate stop condition
}

void I2CSend(uint8_t data)
{
  I2C_Wait();
  SSPBUF = data;         //Write data to SSPBUF
}

uint8_t I2CReceive(uint8_t ack)
{
  uint8_t temp;
  I2C_Wait();
  RCEN = 1;
  I2C_Wait();
  temp = SSPBUF;      //Read data from SSPBUF
  I2C_Wait();
  ACKDT = (ack)?0:1;    //Acknowledge bit
  ACKEN = 1;          //Acknowledge sequence
  return temp;
}

uint8_t GetRTCFormatted() // POPULATE td[] format "20YY-MM-DD HH:MM:SS\r\n"
{
  // transfer over first 8 bytes from RTC
  I2CStart();
  I2CSend(DS1307WriteAddress);
  I2CSend(0); // first set register pointer to DS1307 register 0
  I2CStop();  
  I2CStart(); // repeated start
  I2CSend(DS1307ReadAddress);
  I2CBuf[0]=I2CReceive(1); // read byte
  I2CBuf[1]=I2CReceive(1); // read byte
  I2CBuf[2]=I2CReceive(1); // read byte
  I2CBuf[3]=I2CReceive(1); // read byte
  I2CBuf[4]=I2CReceive(1); // read byte
  I2CBuf[5]=I2CReceive(1); // read byte
  I2CBuf[6]=I2CReceive(0); // read byte no ACK
  I2CStop();  
  // Convert BCD to numbers (date) td[] = "20YY-MM-DD HH:MM:SS\r\n"; 
  td[0] = '2';
  td[1] = '0';
  td[3] = 48+(I2CBuf[6]&0x0f); //YY (L)
  td[2] = 48+((I2CBuf[6]>>4)&0x0f); //YY (H)
  td[4] = '-';
  td[6] = 48+(I2CBuf[5]&0x0f); //MM (L)
  td[5] = 48+((I2CBuf[5]>>4)&0x0f); //MM (H)
  td[7] = '-';
  td[9] = 48+(I2CBuf[4]&0x0f); //DD (L)
  td[8] = 48+((I2CBuf[4]>>4)&0x0f); //DD (H)
  td[10] = ' ';
  // (time))
  td[12] = 48+(I2CBuf[2]&0x0f); //HH (L)
  td[11] = 48+((I2CBuf[2]>>4)&0x03); //HH (H) dont include 24/23 hr control bit
  td[13] = ':';
  td[15] = 48+(I2CBuf[1]&0x0f); //MM (L)
  td[14] = 48+((I2CBuf[1]>>4)&0x0f); //MM (H)
  td[16] = ':';
  td[18] = 48+(I2CBuf[0]&0x0f); //SS (L)
  td[17] = 48+((I2CBuf[0]>>4)&0x07); //SS (H) dont include CH control bit
  td[19] = '\r';
  td[20] = '\n';
  return 21;
}

uint8_t GetRTCUnformatted() // POPULATE td[] format "YMDDHMS\r\n"
{
  // transfer over first 8 bytes from RTC
  I2CStart();
  I2CSend(DS1307WriteAddress);
  I2CSend(0); // first set register pointer to DS1307 register 0
  I2CStop();  
  I2CStart(); // repeated start
  I2CSend(DS1307ReadAddress);
  td[6]=I2CReceive(1); // read byte YY
  td[5]=I2CReceive(1); // read byte MM
  td[4]=I2CReceive(1); // read byte DD
  td[3]=I2CReceive(1); // read byte Day Of Week
  td[2]=I2CReceive(1); // read byte HH
  td[1]=I2CReceive(1); // read byte MM
  td[0]=I2CReceive(0); // read byte SS
  td[7]='\r';
  td[8]='\n';
  return 9;
  I2CStop();  
}

uint8_t SetRTC() // extract time/date info from RXData[] array, change to BCD and send to RTC (no checks)
{
  if(KeyBuf[1]=='B' || KeyBuf[1]=='b')
  {
    // parses RXData S=YYMMDDHHMMSS to set DS1307 RTC
    // basic syntax/error checks
    if(KeyBuf[2]!='=') return 1;
    if(KeyBuf[3]<0x17 || KeyBuf[3]>0x99) return 2; // year 17..99
    if(KeyBuf[4]<0x01 || KeyBuf[4]>0x12) return 3; // month 1..12
    if(KeyBuf[5]<0x01 || KeyBuf[5]>0x31) return 4; // day 1..31
    if(KeyBuf[5]<1 || KeyBuf[6]>7) return 5; // day of week 1..7
    if(KeyBuf[7]>0x24) return 6; // hour>24
    if(KeyBuf[8]>0x59) return 7; // min>59
    if(KeyBuf[9]>0x59) return 8; // sec>59
    I2CBuf[6] = KeyBuf[3]; // YY BCD
    I2CBuf[5] = KeyBuf[4]; // MM BCD
    I2CBuf[4] = KeyBuf[5]; // DD BCD
    I2CBuf[3] = KeyBuf[6]; // DOW BCD
    I2CBuf[2] = KeyBuf[7] | 0x40; // HH BCD and set 24 hr bit
    I2CBuf[1] = KeyBuf[8]; // MM BCD
    I2CBuf[0] = KeyBuf[9] & 0x7f; // SS BCD and clr clock enable bit
  }
  else
  {  
    if(KeyBuf[1]!='=') return 1;
    if(KeyBuf[2]<48 || KeyBuf[2]>57) return 2; // YYx10 
    if(KeyBuf[3]<48 || KeyBuf[3]>57) return 2; // YY
    if(KeyBuf[4]<48 || KeyBuf[4]>51) return 3; // MMx10
    if(KeyBuf[5]<48 || KeyBuf[5]>57) return 3; // MM
    if(KeyBuf[6]<48 || KeyBuf[6]>52) return 4; // DDx10
    if(KeyBuf[7]<48 || KeyBuf[7]>57) return 4; // DD
    if(KeyBuf[8]<48 || KeyBuf[8]>51) return 5; // HHx10
    if(KeyBuf[9]<48 || KeyBuf[9]>57) return 5; // HH
    if(KeyBuf[10]<48 || KeyBuf[10]>53) return 7; // MMx10
    if(KeyBuf[11]<48 || KeyBuf[11]>57) return 7; // MM
    if(KeyBuf[12]<48 || KeyBuf[12]>53) return 8; // SSx10
    if(KeyBuf[13]<48 || KeyBuf[13]>57) return 8; // SS
    // (pack date as BCD)
    I2CBuf[6] = (KeyBuf[2]-48)<<4 | (KeyBuf[3]-48); // YY BCD
    I2CBuf[5] = (KeyBuf[4]-48)<<4 | (KeyBuf[5]-48); // MM BCD
    I2CBuf[4] = (KeyBuf[6]-48)<<4 | (KeyBuf[7]-48); // DD BCD
    // (pack time as BCD)
    I2CBuf[3] = 1; // day of week (not used)
    I2CBuf[2] = (KeyBuf[8]-48)<<4 | (KeyBuf[9]-48) | 0x40; // HH BCD + set 24 hr bit
    I2CBuf[1] = (KeyBuf[10]-48)<<4 | (KeyBuf[11]-48); // MM BCD
    I2CBuf[0] = ((KeyBuf[12]-48)<<4 | (KeyBuf[13]-48)) & 0x7f; // SS BCD + clr clock enable bit
  }  
  // transfer over first 8 bytes from RTC
  I2CStart();
  I2CSend(DS1307WriteAddress);
  I2CSend(0); // set register pointer to first register 0
  I2CSend(I2CBuf[0]); // write reg
  I2CSend(I2CBuf[1]); // write reg
  I2CSend(I2CBuf[2]); // write reg
  I2CSend(I2CBuf[3]); // write reg
  I2CSend(I2CBuf[4]); // write reg
  I2CSend(I2CBuf[5]); // write reg
  I2CSend(I2CBuf[6]); // write reg
  I2CStop();  
  return 99;
}

void InitRTC()
{
  led=60000;
  I2CStart();
  // Need to clear MSB of seconds register so clock will start
  I2CSend(DS1307WriteAddress);
  I2CSend(0); // first set register pointer to DS1307 register 0
  I2CStop();  
  I2CStart(); // repeated start
  I2CSend(DS1307ReadAddress);
  I2CBuf[0]=I2CReceive(0) & 0x7F; // read byte SS and CLR CH Bit
  // write it back out
  I2CStart();
  I2CSend(DS1307WriteAddress);
  I2CSend(0); // set register pointer to first register 0
  I2CSend(I2CBuf[0]); // write reg
  I2CStop();  
}

char UCASE(char input)
{
  if(input>='a' && input<='z')
    return input-32;
  else
    return input;
}

static void send_string_sync(uint8_t endpoint, const char *str)
{
  char *in_buf = (char*) usb_get_in_buffer(endpoint);
  while (usb_in_endpoint_busy(endpoint));
  strcpy(in_buf, str);
  usb_send_in_buffer(endpoint, strlen(in_buf));
}

int main(void)
{
  uint8_t send = 1;
  uint8_t i,sz,LastErr;
  int mptr=0;  
  int SendFirstMsg = sizeof(help);

  OSCCONbits.IRCF = 0b1111;
  ACTCONbits.ACTSRC = 1;
  ACTCONbits.ACTEN = 1;
  INTCONbits.PEIE = 1;
  INTCONbits.GIE = 1;

  ANSELC=0;   // init I/O
  TRISA=0x00; // N/U all ports output
  TRISC=0x03; // I2C inputs all rest outputs
  LATC=0xff;  // I2C pins high
  
  // Init I2C
  SSPCON = 0b00101000;            //SSP Module as Master
  SSPCON2 = 0;
  SSPADD = 200; // Clock Speed 100Khz
  SSPSTAT = 0;
  
  usb_init();

  InitRTC();  // init

  while (1) 
  {
    if (usb_is_configured() && !usb_in_endpoint_halted(2) && !usb_in_endpoint_busy(2) && send) // Send datetime to the PC
    {
      TXData = usb_get_in_buffer(2);
      if(SendFirstMsg>0)
      {  
        // Send out initial help message string on first use
        i=0;
        while(SendFirstMsg && i<64)
        {
          TXData[i++] = help[mptr++];
          SendFirstMsg--;
        }
        usb_send_in_buffer(2, i);
      }
      else
      {    
        if(send==1) sz=GetRTCFormatted();  // Retrieves DS1307 RTC values and formats values into td for transmission
        if(send==2) sz=GetRTCUnformatted();  // Retrieves DS1307 RTC values and formats values into td for transmission
        if(send==3) // send ok message if clock set
        {
          td[0]='\r'; td[1]='\n'; td[2]='O'; td[3]='K'; td[4]='\r'; td[5]='\n';
          sz=6;
        }  
        if(send==4) // send ok message if clock set
        {
          for(i=0;i<22;i++)
            td[i]=err[LastErr][i];
          sz=22;
        }  
        // send out timedate string
        for(i=0; i<sz; i++)
          TXData[i]=td[i];
        usb_send_in_buffer(2, sz);
        send=0;
        mptr=0;
        RXLen = usb_get_out_buffer(2, &RXData); // clr input buffer
      }  
      led=30000; // turn led on when we send. send =1 initially so will flash when plugged-in
    }
    if (usb_is_configured() && !usb_out_endpoint_halted(2) && usb_out_endpoint_has_data(2)) // parse received characters. Assume data will come in single string
    {
      RXLen = usb_get_out_buffer(2, &RXData);
      if(UCASE(RXData[0])=='F') send=1; // Request to send out formatted date
      if(UCASE(RXData[0])=='U') send=2; // Request to send out unformatted date
      if (send==0)
      {  
        // build up input string to check for set datetime
        i=0;
        LastErr=0;
        while(i<RXLen)
        {        
          TXData[i]=UCASE(RXData[i]); // local echo
          KeyBuf[mptr++]=UCASE(RXData[i++]);  // store/build input line
          if(KeyBuf[0]!='S') send=4;
          if ( mptr>14)
          {
            LastErr=SetRTC();
            if(LastErr==99) // parses RXData YYMMDDHHMMSS to set DS1307 RTC
              send=3;   // Send OK
            else
              send=4;   // flag error
          }
          if (mptr>16) send=4; // flag error on too many chars
        }  
        usb_send_in_buffer(2, i); // local echo
      }  
      usb_arm_out_endpoint(2);
    }
    if(usb_is_configured() && led) // if plugged in and working and led variable > 0 then led on
    {
      led--;
      ACT_LED(1);
    }
    else
      ACT_LED(0);
  }
}

/* Callbacks. These function names are set in usb_config.h. */
int8_t app_set_line_coding_callback(uint8_t interface, const struct cdc_line_coding *coding)
{
  line_coding = *coding;
  return 0;
}

int8_t app_get_line_coding_callback(uint8_t interface, struct cdc_line_coding *coding)
{
  /* This is where baud rate, data, stop, and parity bits are set. */
  *coding = line_coding;
  return 0;
}

void app_set_configuration_callback(uint8_t configuration)
{
}

uint16_t app_get_device_status_callback()
{
  return 0x0000;
}

void app_endpoint_halt_callback(uint8_t endpoint, bool halted)
{
}

int8_t app_set_interface_callback(uint8_t interface, uint8_t alt_setting)
{
  return 0;
}

int8_t app_get_interface_callback(uint8_t interface)
{
  return 0;
}

void app_out_transaction_callback(uint8_t endpoint)
{
}

void app_in_transaction_complete_callback(uint8_t endpoint)
{
}

int8_t app_unknown_setup_request_callback(const struct setup_packet *setup)
{
  return process_cdc_setup_request(setup);
}

int16_t app_unknown_get_descriptor_callback(const struct setup_packet *pkt, const void **descriptor)
{
  return -1;
}

void app_start_of_frame_callback(void)
{
}

void app_usb_reset_callback(void)
{
}

int8_t app_send_encapsulated_command(uint8_t interface, uint16_t length)
{
  return -1;
}

int16_t app_get_encapsulated_response(uint8_t interface, uint16_t length, const void **report, usb_ep0_data_stage_callback *callback,void **context)
{
  return -1;
}

int8_t app_set_comm_feature_callback(uint8_t interface, bool idle_setting, bool data_multiplexed_state)
{
  return -1;
}

int8_t app_clear_comm_feature_callback(uint8_t interface, bool idle_setting, bool data_multiplexed_state)
{
  return -1;
}

int8_t app_get_comm_feature_callback(uint8_t interface, bool *idle_setting, bool *data_multiplexed_state)
{
  return -1;
}


int8_t app_set_control_line_state_callback(uint8_t interface, bool dtr, bool dts)
{
  return 0;
}

int8_t app_send_break_callback(uint8_t interface, uint16_t duration)
{
  return 0;
}

